# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Pipe_GUI.ui'
#
# Created by: PyQt5 UI code generator 5.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(867, 665)
        self.groupBox_input = QtWidgets.QGroupBox(Dialog)
        self.groupBox_input.setGeometry(QtCore.QRect(10, 10, 841, 91))
        self.groupBox_input.setObjectName("groupBox_input")
        self.pushButton = QtWidgets.QPushButton(self.groupBox_input)
        self.pushButton.setGeometry(QtCore.QRect(10, 20, 191, 28))
        self.pushButton.setObjectName("pushButton")
        self.textEdit_filepath = QtWidgets.QTextEdit(self.groupBox_input)
        self.textEdit_filepath.setGeometry(QtCore.QRect(240, 20, 591, 51))
        self.textEdit_filepath.setObjectName("textEdit_filepath")
        self.pushButton_exit = QtWidgets.QPushButton(Dialog)
        self.pushButton_exit.setGeometry(QtCore.QRect(400, 620, 93, 28))
        self.pushButton_exit.setObjectName("pushButton_exit")
        self.groupBox_pipes = QtWidgets.QGroupBox(Dialog)
        self.groupBox_pipes.setGeometry(QtCore.QRect(10, 110, 841, 491))
        self.groupBox_pipes.setObjectName("groupBox_pipes")
        self.openGLWidget = QtWidgets.QOpenGLWidget(self.groupBox_pipes)
        self.openGLWidget.setGeometry(QtCore.QRect(10, 20, 821, 451))
        self.openGLWidget.setObjectName("openGLWidget")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.groupBox_input.setTitle(_translate("Dialog", "Pipe File Input"))
        self.pushButton.setText(_translate("Dialog", "Open and Read Pipe File"))
        self.pushButton_exit.setText(_translate("Dialog", "Exit"))
        self.groupBox_pipes.setTitle(_translate("Dialog", "Pipe System"))

